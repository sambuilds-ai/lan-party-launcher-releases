# LAN Party Launcher for Linux x86_64

This archive contains the stable production launcher for 64-bit Linux. It
loads `https://lan.evilarcademachine.com` and runs on X11 and Wayland through
WebKitGTK.

## Quick install (CachyOS / Arch Linux)

The one-command installer downloads the latest verified release, installs it
to `~/.local/share/lan-party-launcher` (override with
`LAN_PARTY_INSTALL_DIR`), and runs the bundled setup:

```bash
curl -fsSL https://lan.evilarcademachine.com/install.sh | bash
```

To install this archive manually instead, extract it into a stable,
user-writable directory and run the bundled setup script from there, using
the actual version number of the file you downloaded (a `v*` glob also
matches any older version's archive or directory sitting in the same place,
and tar/cd then fail):

```bash
tar -xzf lan-party-launcher-v<version>-linux-x86_64.tar.gz
cd lan-party-launcher-v<version>-linux-x86_64
./install-cachyos.sh
./lan-party-launcher
```

Run the script as your normal user; it uses `sudo` only for the package
install. When the `webkit2gtk-4.1` runtime the launcher links against is
missing, the script installs it with `pacman -Syu` — which also upgrades the
system, the safe way to install on Arch — and when it is already present,
nothing is installed. Beyond that, the script restores the launcher's execute
bit when an archive tool dropped it and adds "LAN Party Launcher" to the
desktop's application menu, so after setup the launcher starts from the app
menu with no terminal involved (re-run the script if you move this directory
so the menu entry follows it). The remaining steps check and print guidance:
the install directory, then the Steam and Proton setup used for Windows
cartridges.

To install the runtime manually instead:

```bash
sudo pacman -Syu --needed webkit2gtk-4.1
```

On other distributions, install the WebKitGTK 4.1 runtime with your package
manager (Debian/Ubuntu: `libwebkit2gtk-4.1-0`).

The launcher keeps its configuration, WebKit data, and Proton prefixes in
`data/` beside the executable. Do not move only the binary into `/usr/bin` or
another root-owned directory.

To verify a downloaded release, place `CHECKSUMS.txt` beside the archive and
run:

```bash
sha256sum --check --ignore-missing CHECKSUMS.txt
```

## Windows cartridges through Proton

Install Steam, start it once, and install a Proton compatibility tool. The
launcher discovers Proton from `PROTON_PATH`, then `proton` on `PATH`, then
`compatibilitytools.d` and `steamapps/common` under the Steam roots
(`~/.steam/root`, `~/.local/share/Steam`, and the Flatpak Steam path), and
finally CachyOS's system-wide `/usr/share/steam/compatibilitytools.d` — so
CachyOS's packaged Proton build (for example
`/usr/share/steam/compatibilitytools.d/proton-cachyos-slr/proton`) is found
automatically.

To force a specific Proton, point `PROTON_PATH` at its `proton` script —
`install-cachyos.sh` prints the exact command when it detects one. This form
works in both Bash and fish:

```bash
env PROTON_PATH=/usr/share/steam/compatibilitytools.d/proton-cachyos-slr/proton \
  ./lan-party-launcher
```

Each cartridge receives an isolated prefix under
`data/proton-prefixes/<game-slug>`. Steam games are dispatched through the
system's registered `steam://` handler.

Windows `.exe` cartridges are supported through Proton. Windows `.cmd` and
`.bat` wrappers, WFRR injection, FiveM, and launcher capture integrations are
not currently supported on Linux.

### Managed prefix bootstrap (Renegade X)

Some Windows payloads statically import Microsoft runtimes that Wine's
builtins cannot stand in for. Renegade X's `UDK.exe` needs the June 2010
DirectX components (`d3dcompiler_43`, `d3dx9_43`, `d3dx11_43`) and the VC++
2010 runtime; without the genuine DLLs it exits with "Failed to compile
default material" before drawing a frame. For such games the launcher:

- downloads a small, hash-pinned support archive with the game (for Renegade
  X it is extracted from Epic's `UE3Redist.exe` inside the official Game
  Centre installer) into `data/support/<game>/`;
- on the first Play, lets Proton create the game's own prefix
  (`data/proton-prefixes/renegade-x`), copies the pinned DLLs into that
  prefix's `system32`/`syswow64` after checking every hash, records
  `lanparty-bootstrap.json` there, and logs to `lanparty-bootstrap.log`
  beside it;
- starts the game with `WINEDLLOVERRIDES` preferring those DLLs. Proton's own
  DXVK stays in charge of Direct3D 9; the cart's `d3d9_disabled.dll` is inert.

Nothing is installed system-wide and no other prefix is touched. The first
launch therefore takes a minute or two longer than later ones. Deleting the
prefix directory makes the next launch redo the bootstrap. Two environment
knobs exist for diagnosis: `LAN_PARTY_RENX_NATIVE_XAUDIO=1` also installs
the native XAudio 2.7 DLLs (the default keeps Proton's FAudio-backed
builtins), and `LAN_PARTY_SKIP_PROTON_BOOTSTRAP=1` launches without the
bootstrap. For these games the launcher also keeps Proton's stderr (Wine
`err:`/`fixme:` and DXVK lines) as `proton-stderr.log` in the game's
per-player `data/userdata/<player>/<game>` directory, and starting the
launcher with `PROTON_LOG=1` writes Proton's full log there as
`steam-lanparty-<game>.log` (the launcher supplies the `SteamGameId` and
`PROTON_LOG_DIR` Proton needs before it writes one).

## Updates and diagnostics

The launcher updates itself: it checks the release manifest at startup and
stages a verified new binary, and the dashboard header's update button applies
one on demand (the window closes and reopens on the new version). The binary
is swapped in place, so `data/` — login, configuration, installed-game
records, and the Proton prefixes with their save games — stays untouched. The
surrounding directory keeps its original versioned name; the running version
is what the header reports, not what the folder is called. If the launcher
ever fails to start right after an update, the previous binary is still there
as `lan-party-launcher.old` — rename it back over `lan-party-launcher`.

Older launchers (through v0.17.1) cannot replace themselves. To update one of
those manually: quit the running launcher, download and extract the newer
archive, then move `data/` from the previous version's directory to sit
beside the new executable. Starting the new version without it means starting
from scratch while the old directory still holds your state.

```bash
tar -xzf lan-party-launcher-v<new-version>-linux-x86_64.tar.gz
mv lan-party-launcher-v<old-version>-linux-x86_64/data \
  lan-party-launcher-v<new-version>-linux-x86_64/data
```

Delete the old version's directory afterwards.

While the launcher is running, this command checks its local companion agent:

```bash
curl --fail --silent http://127.0.0.1:3334/health
```

The launcher guards against NVIDIA's Wayland explicit-sync crash automatically
while keeping WebKitGTK's DMA-BUF hardware renderer enabled. It logs
`__NV_DISABLE_EXPLICIT_SYNC=1` at startup on affected machines. Mesa GPUs and
real X11 sessions are left untouched.

If an NVIDIA driver/WebKitGTK combination still exits with `Gdk-Message: Error
71 (Protocol error) dispatching to Wayland display` before a window appears,
use the crash-safe software fallback:

```bash
env WEBKIT_DISABLE_DMABUF_RENDERER=1 ./lan-party-launcher
```

That fallback is intentionally opt-in because it paints the dashboard on the
CPU and can make scrolling very slow on large or high-DPI displays. Do not use
`GDK_BACKEND=x11` as the fallback on NVIDIA: affected WebKitGTK versions can
open a live window that never paints after a GBM buffer allocation failure.
