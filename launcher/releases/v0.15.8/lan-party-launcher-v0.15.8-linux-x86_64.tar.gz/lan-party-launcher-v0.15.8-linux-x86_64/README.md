# LAN Party Launcher for Linux x86_64

This archive contains the stable production launcher for 64-bit Linux. It
loads `https://lan.evilarcademachine.com` and runs on X11 and Wayland through
WebKitGTK.

## Quick install (CachyOS / Arch Linux)

Extract the archive into a stable, user-writable directory and run the bundled
setup script from there:

```bash
tar -xzf lan-party-launcher-v*-linux-x86_64.tar.gz
cd lan-party-launcher-v*-linux-x86_64
./install-cachyos.sh
./lan-party-launcher
```

Run the script as your normal user; it uses `sudo` only for the package
install. When the `webkit2gtk-4.1` runtime the launcher links against is
missing, the script installs it with `pacman -Syu` — which also upgrades the
system, the safe way to install on Arch — and when it is already present,
nothing is installed. Beyond that, its only change is restoring the
launcher's execute bit when an archive tool dropped it; the remaining steps
check and print guidance: the install directory, then the Steam and Proton
setup used for Windows cartridges.

To install the runtime manually instead:

```bash
sudo pacman -Syu --needed webkit2gtk-4.1
```

On other distributions, install the WebKitGTK 4.1 runtime with your package
manager (Debian/Ubuntu: `libwebkit2gtk-4.1-0`).

The launcher keeps its configuration, WebKit data, and Proton prefixes in
`data/` beside the executable. Do not move only the binary into `/usr/bin` or
another root-owned directory.

To verify a downloaded release, place `CHECKSUMS.txt` beside the archive and
run:

```bash
sha256sum --check --ignore-missing CHECKSUMS.txt
```

## Windows cartridges through Proton

Install Steam, start it once, and install a Proton version through Steam. The
launcher discovers Proton from `PROTON_PATH`, then from `compatibilitytools.d`
and `steamapps/common` under the Steam roots (`~/.steam/root`,
`~/.local/share/Steam`, and the Flatpak Steam path), and finally from `proton`
on `PATH`.

CachyOS's packaged Proton under `/usr/share/steam/compatibilitytools.d` is not
searched automatically. Point `PROTON_PATH` at its `proton` script to use it —
`install-cachyos.sh` prints the exact command when it detects one. This form
works in both Bash and fish:

```bash
env PROTON_PATH=/usr/share/steam/compatibilitytools.d/proton-cachyos/proton \
  ./lan-party-launcher
```

Each cartridge receives an isolated prefix under
`data/proton-prefixes/<game-slug>`. Steam games are dispatched through the
system's registered `steam://` handler.

Windows `.exe` cartridges are supported through Proton. Windows `.cmd` and
`.bat` wrappers, WFRR injection, FiveM, and launcher capture integrations are
not currently supported on Linux.

## Updates and diagnostics

Linux builds do not replace themselves. Download and extract the newer Linux
archive manually when a new stable release is published.

While the launcher is running, this command checks its local companion agent:

```bash
curl --fail --silent http://127.0.0.1:3334/health
```
