# LAN Party Launcher

Desktop shell and local companion agent for the LAN Party dashboard. The Rust
application uses tao/wry to load the production dashboard, and exposes the
loopback agent at `127.0.0.1:3334` for approved local actions such as launching
games. Windows is the supported release platform; Linux can be built locally.

## Local verification

```bash
cd launcher
./scripts/build.sh
```

The script runs release-profile tests and cross-compiles
`target/x86_64-pc-windows-gnu/release/lan-party-launcher.exe` with
`https://lan.evilarcademachine.com` as the dashboard URL.

The result is a verification artifact only. The script does not package or
publish it, create a build ID, or copy it to Windows, a NAS, or
`public/downloads/`.

## CachyOS / Arch Linux local build

Install the native WebKitGTK toolchain and build:

```bash
sudo pacman -S --needed base-devel rust pkgconf gtk3 webkit2gtk-4.1
cd launcher
./scripts/build-linux.sh
./target/release/lan-party-launcher
```

The Linux binary uses WebKitGTK rather than WebView2. Stable releases publish a
separate `linux-x86_64.tar.gz` artifact alongside the Windows `.exe` and
installer. Automatic replacement remains disabled on Linux; download and
extract the newer Linux archive when updating.

Windows cartridge executables are launched through Proton automatically. The
launcher searches `PROTON_PATH`, Steam's `compatibilitytools.d`, installed Steam
Proton versions, and finally `proton` on `PATH`. Start Steam once before using
the launcher. Each cartridge receives an isolated prefix under
`data/proton-prefixes/<game-slug>`. To force Proton-CachyOS or GE-Proton:

```bash
PROTON_PATH="$HOME/.steam/root/compatibilitytools.d/GE-Proton/proton" \
  ./target/release/lan-party-launcher
```

## Release and installation

There is one launcher channel: stable production. Pushing launcher changes to
`main` automatically tests and builds the release payload, publishes the stable
source release, verifies its assets and checksums, and mirrors those exact files
to the public
[`lan-party-launcher-releases`](https://github.com/sambuilds-ai/lan-party-launcher-releases)
repository. It does not deploy the dashboard or CT117; those remain the manual
web deployment flow documented in the
[deployment workflow](../deploy/WORKFLOW.md). Dashboard download routes resolve
the public mirror directly, so there is no separate launcher-artifact promotion
step. Do not create dev builds, beta releases, or manual launcher tags.

The installer places the application under `%LOCALAPPDATA%\LAN Party`;
installed clients check the verified public production mirror when they start.

## How It Works

- WebView2 displays `https://lan.evilarcademachine.com`.
- The loopback agent at `127.0.0.1:3334` lets the dashboard launch configured
  executables and Steam URLs without exposing that control to the LAN.
- Replay monitoring covers supported game directories.
- WFRR sidecars provide registry and filesystem redirection for legacy games.
- The updater accepts only newer stable versions and verifies release checksums.
