#!/usr/bin/env bash
# One-time setup for the LAN Party launcher on CachyOS / Arch Linux.
#
# Run this as your normal user from the extracted release directory, beside
# ./lan-party-launcher. When the WebKitGTK runtime is missing it installs it
# with `pacman -Syu` (sudo is used for that one command; on Arch, installing
# without the accompanying system upgrade is how partial-upgrade breakage
# happens). Beyond that its only change is restoring the launcher's execute
# bit when an archive tool dropped it; every other step checks and prints
# guidance: the install directory, then the Steam and Proton setup used to
# run Windows cartridges.
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"

if (( $# != 0 )); then
    echo "Usage: ./install-cachyos.sh" >&2
    exit 2
fi

if [[ "$(uname -s)" != "Linux" ]]; then
    echo "ERROR: The Linux launcher only runs on Linux." >&2
    exit 1
fi

# Under sudo the directory, Steam, and Proton checks would describe root's
# environment (HOME=/root, everything writable) instead of the user who
# actually plays, inverting their answers.
if (( EUID == 0 )) && [[ -n "${SUDO_USER:-}" ]]; then
    echo "ERROR: Run this script as your normal user, not under sudo." >&2
    echo "It runs sudo itself for the single package install; the other" >&2
    echo "checks must run as the user who will start the launcher." >&2
    exit 1
fi

if [[ ! -f "$SCRIPT_DIR/lan-party-launcher" ]]; then
    echo "ERROR: lan-party-launcher was not found beside this script." >&2
    echo "Extract the full release archive and run ./install-cachyos.sh from" >&2
    echo "the extracted directory." >&2
    exit 1
fi

echo "=== LAN Party Launcher Linux setup ==="

warnings=0
start_cmd="./lan-party-launcher"

echo "[1/3] Checking the WebKitGTK runtime..."
if command -v pacman >/dev/null 2>&1; then
    if pacman -Q webkit2gtk-4.1 >/dev/null 2>&1; then
        echo "      OK: webkit2gtk-4.1 is already installed."
    else
        echo "      Installing webkit2gtk-4.1 with pacman -Syu. This also"
        echo "      upgrades the system: on Arch, installing against a stale"
        echo "      sync database is how partial-upgrade breakage happens."
        pacman_cmd=(pacman -Syu --needed webkit2gtk-4.1)
        if (( EUID != 0 )); then
            pacman_cmd=(sudo "${pacman_cmd[@]}")
        fi
        if ! "${pacman_cmd[@]}"; then
            warnings=$((warnings + 1))
            echo "      WARNING: the install did not complete. The launcher"
            echo "      needs the webkit2gtk-4.1 package; install it and re-run"
            echo "      this script. Continuing with the remaining checks..."
        fi
    fi
else
    echo "      pacman was not found. Install the WebKitGTK 4.1 runtime with"
    echo "      your distribution's package manager instead"
    echo "      (Debian/Ubuntu: sudo apt install libwebkit2gtk-4.1-0)."
fi

echo "[2/3] Checking the install directory..."
if [[ -w "$SCRIPT_DIR" ]]; then
    echo "      OK: $SCRIPT_DIR is writable. Launcher state lives in data/"
    echo "      beside the executable."
else
    warnings=$((warnings + 1))
    echo "      WARNING: $SCRIPT_DIR is not writable by $(id -un). The"
    echo "      launcher stores its configuration, WebKit data, and Proton"
    echo "      prefixes in data/ beside the executable; move the extracted"
    echo "      directory somewhere user-writable."
fi
if [[ ! -x "$SCRIPT_DIR/lan-party-launcher" ]]; then
    if chmod u+x "$SCRIPT_DIR/lan-party-launcher" 2>/dev/null; then
        echo "      Restored the execute bit on lan-party-launcher."
    else
        warnings=$((warnings + 1))
        echo "      WARNING: lan-party-launcher is not executable and the"
        echo "      execute bit could not be restored. Re-extract the archive"
        echo "      with tar -xzf instead of a GUI archive tool."
    fi
fi

echo "[3/3] Checking Steam and Proton (needed only for Windows cartridges)..."
home="${HOME:-/nonexistent}"
steam_roots=(
    "$home/.steam/root"
    "$home/.local/share/Steam"
    "$home/.var/app/com.valvesoftware.Steam/data/Steam"
)

steam_root=""
for root in "${steam_roots[@]}"; do
    if [[ -d "$root/steamapps" ]]; then
        steam_root="$root"
        break
    fi
done
if [[ -n "$steam_root" ]]; then
    echo "      OK: Steam found at $steam_root."
else
    warnings=$((warnings + 1))
    echo "      WARNING: Steam was not found. Windows cartridges run through"
    echo "      Proton, which requires Steam: install Steam, start it once,"
    echo "      then re-run this script."
fi

# Mirror the launcher's own discovery: PROTON_PATH first, else the greatest
# sorted candidate from the Steam roots' compatibility tools and installed
# Proton versions, else proton on PATH.
proton=""
if [[ -n "${PROTON_PATH:-}" && -f "$PROTON_PATH" ]]; then
    proton="$PROTON_PATH (from PROTON_PATH)"
else
    candidates=()
    for root in "${steam_roots[@]}"; do
        for candidate in "$root"/compatibilitytools.d/*/proton \
            "$root"/steamapps/common/*/proton; do
            if [[ -f "$candidate" ]]; then
                candidates+=("$candidate")
            fi
        done
    done
    if (( ${#candidates[@]} > 0 )); then
        proton="$(printf '%s\n' "${candidates[@]}" | LC_ALL=C sort | tail -n 1)"
    elif command -v proton >/dev/null 2>&1; then
        proton="$(command -v proton)"
    fi
fi

if [[ -n "$proton" ]]; then
    echo "      OK: the launcher will discover Proton at:"
    echo "        $proton"
else
    # The launcher does not search the system-wide CachyOS directory; hand
    # the user the exact PROTON_PATH command when a packaged Proton is there.
    system_proton=""
    for candidate in /usr/share/steam/compatibilitytools.d/*/proton; do
        if [[ -f "$candidate" ]]; then
            system_proton="$candidate"
        fi
    done
    if [[ -n "$system_proton" ]]; then
        start_cmd="env PROTON_PATH=$system_proton ./lan-party-launcher"
        echo "      Found CachyOS's packaged Proton, which the launcher does"
        echo "      not search automatically. Start the launcher with the"
        echo "      PROTON_PATH command shown at the end of this setup."
    else
        warnings=$((warnings + 1))
        echo "      WARNING: No Proton found. Install one in Steam"
        echo "      (Settings -> Compatibility), or install CachyOS's"
        echo "      proton-cachyos package and re-run this script for the"
        echo "      PROTON_PATH command."
    fi
fi

echo
if (( warnings > 0 )); then
    echo "=== Setup finished with $warnings warning(s) — fix the items above ==="
else
    echo "=== Setup complete ==="
fi
echo "Start the launcher with:"
echo "  $start_cmd"
echo "If it exits with a Wayland 'Error 71 (Protocol error)' before a window"
echo "appears, retry through XWayland with:"
echo "  env GDK_BACKEND=x11 ./lan-party-launcher"
echo "While it runs, verify the local companion agent with:"
echo "  curl --fail --silent http://127.0.0.1:3334/health"
