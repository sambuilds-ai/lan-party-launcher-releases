# LAN Party Launcher for Linux x86_64

This archive contains the stable production launcher for 64-bit Linux. It
loads `https://lan.evilarcademachine.com` and runs on X11 and Wayland through
WebKitGTK.

## Quick install (CachyOS / Arch Linux)

Extract the archive into a stable, user-writable directory and run the bundled
setup script from there, using the actual version number of the file you
downloaded (a `v*` glob also matches any older version's archive or directory
sitting in the same place, and tar/cd then fail):

```bash
tar -xzf lan-party-launcher-v<version>-linux-x86_64.tar.gz
cd lan-party-launcher-v<version>-linux-x86_64
./install-cachyos.sh
./lan-party-launcher
```

Run the script as your normal user; it uses `sudo` only for the package
install. When the `webkit2gtk-4.1` runtime the launcher links against is
missing, the script installs it with `pacman -Syu` — which also upgrades the
system, the safe way to install on Arch — and when it is already present,
nothing is installed. Beyond that, the script restores the launcher's execute
bit when an archive tool dropped it and adds "LAN Party Launcher" to the
desktop's application menu, so after setup the launcher starts from the app
menu with no terminal involved (re-run the script if you move this directory
so the menu entry follows it). The remaining steps check and print guidance:
the install directory, then the Steam and Proton setup used for Windows
cartridges.

To install the runtime manually instead:

```bash
sudo pacman -Syu --needed webkit2gtk-4.1
```

On other distributions, install the WebKitGTK 4.1 runtime with your package
manager (Debian/Ubuntu: `libwebkit2gtk-4.1-0`).

The launcher keeps its configuration, WebKit data, and Proton prefixes in
`data/` beside the executable. Do not move only the binary into `/usr/bin` or
another root-owned directory.

To verify a downloaded release, place `CHECKSUMS.txt` beside the archive and
run:

```bash
sha256sum --check --ignore-missing CHECKSUMS.txt
```

## Windows cartridges through Proton

Install Steam, start it once, and install a Proton compatibility tool. The
launcher discovers Proton from `PROTON_PATH`, then `proton` on `PATH`, then
`compatibilitytools.d` and `steamapps/common` under the Steam roots
(`~/.steam/root`, `~/.local/share/Steam`, and the Flatpak Steam path), and
finally CachyOS's system-wide `/usr/share/steam/compatibilitytools.d` — so
CachyOS's packaged Proton build (for example
`/usr/share/steam/compatibilitytools.d/proton-cachyos-slr/proton`) is found
automatically.

To force a specific Proton, point `PROTON_PATH` at its `proton` script —
`install-cachyos.sh` prints the exact command when it detects one. This form
works in both Bash and fish:

```bash
env PROTON_PATH=/usr/share/steam/compatibilitytools.d/proton-cachyos-slr/proton \
  ./lan-party-launcher
```

Each cartridge receives an isolated prefix under
`data/proton-prefixes/<game-slug>`. Steam games are dispatched through the
system's registered `steam://` handler.

Windows `.exe` cartridges are supported through Proton. Windows `.cmd` and
`.bat` wrappers, WFRR injection, FiveM, and launcher capture integrations are
not currently supported on Linux.

## Updates and diagnostics

The launcher updates itself: it checks the release manifest at startup and
stages a verified new binary, and the dashboard header's update button applies
one on demand (the window closes and reopens on the new version). The binary
is swapped in place, so `data/` — login, configuration, installed-game
records, and the Proton prefixes with their save games — stays untouched. The
surrounding directory keeps its original versioned name; the running version
is what the header reports, not what the folder is called. If the launcher
ever fails to start right after an update, the previous binary is still there
as `lan-party-launcher.old` — rename it back over `lan-party-launcher`.

Older launchers (through v0.17.1) cannot replace themselves. To update one of
those manually: quit the running launcher, download and extract the newer
archive, then move `data/` from the previous version's directory to sit
beside the new executable. Starting the new version without it means starting
from scratch while the old directory still holds your state.

```bash
tar -xzf lan-party-launcher-v<new-version>-linux-x86_64.tar.gz
mv lan-party-launcher-v<old-version>-linux-x86_64/data \
  lan-party-launcher-v<new-version>-linux-x86_64/data
```

Delete the old version's directory afterwards.

While the launcher is running, this command checks its local companion agent:

```bash
curl --fail --silent http://127.0.0.1:3334/health
```

If the launcher exits with `Gdk-Message: Error 71 (Protocol error) dispatching
to Wayland display` before a window appears, start it through XWayland with
`env GDK_BACKEND=x11 ./lan-party-launcher` (the `env` form works in both Bash
and fish).

The launcher guards against that crash automatically, applying only the brake
the machine needs (it logs which one at startup): Mesa GPUs and X11 sessions
run fully hardware-accelerated; an NVIDIA Wayland session with XWayland
available runs GTK on X11 while keeping WebKitGTK's hardware renderer; only a
pure-Wayland NVIDIA session without XWayland falls back to software rendering
(`WEBKIT_DISABLE_DMABUF_RENDERER=1`). Setting `GDK_BACKEND` or
`WEBKIT_DISABLE_DMABUF_RENDERER` in the environment yourself always wins —
`WEBKIT_DISABLE_DMABUF_RENDERER=0` forces the hardware renderer, `=1` forces
the crash-safe software path.
